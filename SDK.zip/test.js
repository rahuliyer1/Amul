const  FDConnectSDK = require("./index.js");
const { tokenData }  = require("./testData")

var fcn = new FDConnectSDK(tokenData);
fcn.getSessionId().then((response)=>{
    console.log(response)
}).catch((error) => {
  });