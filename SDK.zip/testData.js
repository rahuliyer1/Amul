let MERCHANT_URL = "http://";
let clientTransactionId = "344353";
let amount = 100;


let  transactionDetails= {
    "merchantID" : "470000039748959",
    "clientTransactionId": "34345",
    "transactionType": 'sale',
    "amount": 2200,
    "currencyCode": "INR",
}


let walletData = {
    "firstPayWalletCode": [true,"string"],
    "firstPayWalletName": [true,"string"],

}
let productData = {
    "productId": "P123",
    "productDescription": "Water Bottle",
    "quantity": 1,
    "price": "100",
    "txnAmount": "120",
    "shippingFee": "20",
    "discountPrice": "0"
}
let cardData = {
    "cardNumber" : [true,"number"],
    "expMonth" :[true,"number"],
    "expYear" : [true,"number"],
    "cVV" : [true,"number"],
    "nameOnCard" :[true,"string"],
    "vaultCard" : [true,"boolean"],
}
let name = {
    "firstName": [true,"string"],
    "lastName": [true,"string"],
    "middleName": [true,"string"],
    "suffix": [true,"string"],
}
let billingAddress = {
    "street1": "Ghodbandar Rode",
    "stree2": "Sai Nagar",
    "city": "Mumbai",
    "state": "Maharashtra",
    "country": "India",
    "zipcode": ""
}
 let shippingAddress = {
    "street1": "Ghodbandar Rode",
    "stree2": "Sai nagar",
    "city": "Mumbai",
    "state": "Maharashtra",
    "country": "India",
    "zipcode": ""
 }
let customerDetails = {
    "customerId": "ABC1234",
    "hostedIds": [
       "KRS1220ESFFTR8490"
   ], 
   "name": {
       "firstName": "ABC",
       "lastName": "XYZ",
       "middleName": "DEF",
       "suffix": "ADX"
   },
   "mobileNo": "1234567890",
   "emailId": "abc@gmail.com",
   "billingAddress": billingAddress,
   "shippingAddress": shippingAddress
}
// let tokenData = {
//     "resultURL": "http://",
//     "keyValue" :"kYaobKTw33mlp+TSE3vLVNdPnAw4ISoJ7d8R4CuG074=",
//     "ivValue" : "pNbwPxHCyxiUOkKFHu8ogg==",
//     "transactionDetails": transactionDetails , 
//     "customerDetails": customerDetails ,
//     "productData": productData ,
//     "cardData" : {} , 
//     "walletData" :{} ,  
//     "paymentMethodType":"WALLET",
//     "integrationType":"MERCHANT_PAYMENT_MODE_INTEGRATION"
// };

let tokenData = {
    resultURL: "http://foodhub.storehippo.manu:3000/ms/pages/handleResponse/success/TXN--aDJ4d918?order_ref_id=TXN--aDJ4d918",
    keyValue: "kYaobKTw33mlp+TSE3vLVNdPnAw4ISoJ7d8R4CuG074=",
    ivValue: "pNbwPxHCyxiUOkKFHu8ogg==",
    paymentMethodType: "WALLET",
    integrationType: "MERCHANT_PAYMENT_MODE_INTEGRATION",
    transactionDetails: {
      merchantID: "470000039748959",
      amount: 2200,
      currencyCode: "INR",
      clientTransactionId: "TXN--aDJ4d183",
      transactionType: "SALE",
    },
    customerDetails: {
      name: {
        firstName: "ABC",
        lastName: "XYZ",
        middleName: "DEF",
        suffix: "ADX",
      },
      mobileNo: "1234567890",
      emailId: "abc@gmail.com",
      billingAddress: {
        street1: "Ghodbandar Rode",
        stree2: "Sai Nagar",
        city: "Mumbai",
        state: "Maharashtra",
        country: "India",
        zipcode: "400000",
      },
      shippingAddress: {
        street1: "Ghodbandar Rode",
        stree2: "Sai nagar",
        city: "Mumbai",
        state: "Maharashtra",
        country: "India",
        zipcode: "400000",
      },
    },
    productData: {
      productId: "P123",
      productDescription: "Water Bottle",
      quantity: 1,
      price: "100",
      txnAmount: "120",
      shippingFee: "20",
      discountPrice: "0",
    },
  }

module.exports = {tokenData,customerDetails,name,cardData,productData,walletData,shippingAddress,transactionDetails,billingAddress}