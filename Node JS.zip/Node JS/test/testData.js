let MERCHANT_URL = "http://";
let clientTransactionId = "323463636234HGR12IOI8765fsd";
let amount = 100;

var tokenData = {
    "resultURL": MERCHANT_URL+"/merchantSuccessPage.jsp",
    "keyValue" : "CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=",
    "ivValue":"9T4hd3Nx0b0sMgYuyWLCTg==",
     "transactionDetails": {
        "merchantID" : "470000000332260",
        "clientTransactionId": clientTransactionId,
        "transactionType": 'sale',
        "amount": amount,
        "currencyCode": 'INR'
    }, 
    "customerDetails": {
        "customerId": "ABC1234",
         "hostedIds": [
            "KRS1220ESFFTR8490"
        ], 
        "name": {
            "firstName": "ABC",
            "lastName": "XYZ",
            "middleName": "DEF",
            "suffix": "ADX"
        },
        "mobileNo": 1234567890,
        "emailId": "abc@gmail.com",
        "billingAddress": {
            "street1": "Ghodbandar Rode",
            "stree2": "Sai Nagar",
            "city": "Mumbai",
            "state": "Maharashtra",
            "country": "India",
            "zipcode": 400000
        },
        "shippingAddress": {
            "street1": "Ghodbandar Rode",
            "stree2": "Sai nagar",
            "city": "Mumbai",
            "state": "Maharashtra",
            "country": "India",
            "zipcode": 400000
        }
    },
    "productData": {
            "productId": "P123",
            "productDescription": "Water Bottle",
            "quantity": 1,
            "price": 100,
            "txnAmount": 120,
            "shippingFee": 20,
            "discountPrice": 0
        },
        "walletData" : {
            "firstPayWalletCode": "FRECHG",
            "firstPayWalletName": "Freecharge"

        },
        "cardData" : {
            "cardNumber" : 4035874000424977,
            "expMonth" : 12,
            "expYear" : 24,
            "cVV" : 123,
            "nameOnCard" : "Vishal Utekar",
            "vaultCard" : false
        },
     "paymentMethodType":"CREDITCARD",
     "integrationType":"MERCHANT_PAYMENT_MODE_INTEGRATION"
};
var hostedIds = {
    "resultURL": MERCHANT_URL+"/merchantSuccessPage.jsp",
    "keyValue" : "CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=",
    "ivValue":"9T4hd3Nx0b0sMgYuyWLCTg==",
     "transactionDetails": {
        "merchantID" : "470000000332260",
        "clientTransactionId": clientTransactionId,
        "transactionType": 'sale',
        "amount": amount,
        "currencyCode": 'INR'
    }, 
    "customerDetails": {
        "customerId": "ABC1234",
         "hostedIds": [
            9
        ], 
        "name": {
            "firstName": "ABC",
            "lastName": "XYZ",
            "middleName": "DEF",
            "suffix": "ADX"
        },
        "mobileNo": 1234567890,
        "emailId": "abc@gmail.com",
        "billingAddress": {
            "street1": "Ghodbandar Rode",
            "stree2": "Sai Nagar",
            "city": "Mumbai",
            "state": "Maharashtra",
            "country": "India",
            "zipcode": 400000
        },
        "shippingAddress": {
            "street1": "Ghodbandar Rode",
            "stree2": "Sai nagar",
            "city": "Mumbai",
            "state": "Maharashtra",
            "country": "India",
            "zipcode": 400000
        }
    },
    "productData": {
            "productId": "P123",
            "productDescription": "Water Bottle",
            "quantity": 1,
            "price": "100",
            "txnAmount": "120",
            "shippingFee": "20",
            "discountPrice": "0"
        },
     "paymentMethodType":"CREDITCARD",
     "integrationType":"MERCHANT_PAYMENT_MODE_INTEGRATION"
};


var wrongDataFormat = {
    "resultURL": MERCHANT_URL+"/merchantSuccessPage.jsp",
    "transactionDetails": "",
}

var tokenDataInnerObject = {
    "resultURL": MERCHANT_URL+"/merchantSuccessPage.jsp",
    "transactionDetails": {
            "merchantID" : "470000000332260",
                "clientTransactionId": "sdfsdfsd",
                "transactionType": 'sale',
                "amount": amount,
                "currencyCode": 'INR'
            },
}

module.exports = {tokenDataInnerObject,wrongDataFormat,hostedIds,tokenData};
